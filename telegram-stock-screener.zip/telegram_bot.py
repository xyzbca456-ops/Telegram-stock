from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes
from telegram import Update
from screener import get_stock_info, format_output
from issi_symbols import ISSI_BATCHES
import asyncio, random
BOT_TOKEN = "TOKENMU"

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Bot aktif!")

async def scan(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        await update.message.reply_text("❌ Gunakan: /scan BBRI.JK")
        return
    symbol = context.args[0].upper()
    await update.message.reply_text(f"⏳ Scanning {symbol}...")
    data = get_stock_info(symbol)
    msg = format_output(data)
    await update.message.reply_text(msg)

def run_bot():
    app = ApplicationBuilder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("scan", scan))
    app.run_polling()

if __name__ == "__main__":
    run_bot()
