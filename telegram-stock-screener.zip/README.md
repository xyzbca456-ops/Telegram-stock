# Telegram Stock Screener Bot

Deploy menggunakan Render.